- Smol RRChars Changes -

V1 - Added Chars
Saber (Team Calibur - My OC)
Emile (Team Calibur - My OC)
Splasha (Team Calibur - My OC)
Roar (OC By Garfield&Sonic)
Amitie (Remake of a 2019 Srb2k mod)
Maimy (OC/Webcomic Character by Z-T00N, support the srb2 mod by DrSteph hes cool dude lol)